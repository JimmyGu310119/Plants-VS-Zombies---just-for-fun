#include "FallingSun.hpp"
#include "utils.hpp"
FallingSun::FallingSun(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, randInt(75, WINDOW_WIDTH - 75), y, layer, width, height, animID) { FallingSun::falling_time = randInt(63, 263); }

FallingSun::~FallingSun()
{
}
