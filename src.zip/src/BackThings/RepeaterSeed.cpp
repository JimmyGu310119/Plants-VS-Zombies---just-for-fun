
#include "RepeaterSeed.hpp"

RepeaterSeed::RepeaterSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    suncost = 200;
    lqfnl = 5;
    cool = 240;
}

RepeaterSeed::~RepeaterSeed()
{
}

void RepeaterSeed::Update()
{
}

void RepeaterSeed::OnClick()
{
    if (isclick == 0 && beidakai == 0)
    {
        isclick = 1;
        lqfnl = 5;
    }
}
