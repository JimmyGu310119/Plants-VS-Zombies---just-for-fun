#include "BackGround.hpp"

Background::Background(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
}

Background::~Background()
{
}

void Background::Update()
{
}

void Background::OnClick()
{
}
