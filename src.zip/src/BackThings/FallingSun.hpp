#ifndef FALLINGSUN_HPP__
#define FALLINGSUN_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class FallingSun : public GameObject, public std::enable_shared_from_this<FallingSun>
{
public:
    FallingSun(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~FallingSun() override;
    void Update()
    {
        --falling_time;
        if (falling_time > 0)
        {
            MoveTo(GetX(), GetY() - 2);
        }
        else
        {
            if (existing_time != 300)
            {
                ++existing_time;
            }
            else
            {
                hp = 0;
            }
        }
    }

    void OnClick()
    {
        hp = 0;
        sun_num = 1;
    }

    int falling_time = randInt(63, 263);
    int existing_time = 0;

private:
};

#endif // !FALLINGSUN_HPP__
