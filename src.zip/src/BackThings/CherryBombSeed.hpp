#ifndef CHERRYBOMBSEED_HPP__

#define CHERRYBOMBSEED_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class CherryBombSeed : public GameObject, public std::enable_shared_from_this<CherryBombSeed>
{
public:
    CherryBombSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~CherryBombSeed() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !CHERRYBOMBSEED_HPP__
