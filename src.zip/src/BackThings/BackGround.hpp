#ifndef BACKGROUND_HPP__
#define BACKGROUND_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Background : public GameObject, public std::enable_shared_from_this<Background>
{
public:
    Background(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Background() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !BACKGROUND_HPP__
