#ifndef COOLDOWNMASK_HPP__
#define COOLDOWNMASK_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class CooldownMask : public GameObject, public std::enable_shared_from_this<CooldownMask>
{
public:
    CooldownMask(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~CooldownMask() override;
    void Update() override;
    void OnClick() override;
    int cooltime = 0;

private:
};

#endif // !COOLDOWNMASK_HPP__