
#include "WallnutSeed.hpp"

WallnutSeed::WallnutSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    suncost = 50;
    lqfnl = 3;
    cool = 900;
}

WallnutSeed::~WallnutSeed()
{
}

void WallnutSeed::Update()
{
}

void WallnutSeed::OnClick()
{
    if (isclick == 0 && beidakai == 0)
    {
        isclick = 1;
        lqfnl = 3;
    }
}
