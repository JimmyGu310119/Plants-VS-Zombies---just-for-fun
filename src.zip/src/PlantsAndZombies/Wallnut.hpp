#ifndef WALLNUT_HPP__
#define WALLNUT_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Wallnut : public GameObject, public std::enable_shared_from_this<Wallnut>
{
public:
    Wallnut(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Wallnut() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !WALLNUT_HPP__