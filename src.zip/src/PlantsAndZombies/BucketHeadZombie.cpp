
#include "BucketHeadZombie.hpp"

BucketHeadZombie::BucketHeadZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    type = 3;
    hp = 1300;
    kenyao = 2;
}

BucketHeadZombie::~BucketHeadZombie()
{
}

void BucketHeadZombie::Update()
{
    if (hp > 0 && hp <= 200)
    {
        ChangeImage(IMGID_REGULAR_ZOMBIE);
    }
    if (hp <= 0)
    {
        hp = 0;
    }
    else if (kenyao == 2 && hp > 0)
    {
        MoveTo(GetX() - 1, GetY());
        if (switchoff == 0)
        {
            PlayAnimation(ANIMID_WALK_ANIM);
            switchoff = 1;
        }
    }
}

void BucketHeadZombie::OnClick()
{
}
