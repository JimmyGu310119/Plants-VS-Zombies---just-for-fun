#ifndef SUNFLOWER_HPP__
#define SUNFLOWER_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class SunFlower : public GameObject, public std::enable_shared_from_this<SunFlower>
{
public:
    SunFlower(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~SunFlower() override;
    void Update() override;
    void OnClick() override;
    int producing_time = randInt(30, 600);

private:
};

#endif // !SUNFLOWER_HPP__