
#include "Repeater.hpp"

Repeater::Repeater(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    hp = 300;
    type = 1;
    ispeashooter = 1;
}

Repeater::~Repeater()
{
}

void Repeater::Update()
{
    if (energy == 0)
    {
        --shootingtime;
        if (shootingswitch == 1 && shootingtime <= 0)
        {
            producepea = 1;
            shootingtime = 30;
            secondshoot = 1;
        }
        if (shootingswitch == 1 && shootingtime <= 25 && secondshoot == 1)
        {
            producepea = 1;
            secondshoot = 0;
        }
    }
    else
    {
        producepea = 1;
        shootingtime = 30;
    }
    if (hp <= 0)
    {
        hp = 0;
    }
}

void Repeater::OnClick()
{
    energy = 1;
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
