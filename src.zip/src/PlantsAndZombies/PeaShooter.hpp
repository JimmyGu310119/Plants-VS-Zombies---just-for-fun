#ifndef PEASHOOTER_HPP__
#define PEASHOOTER_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class PeaShooter : public GameObject, public std::enable_shared_from_this<PeaShooter>
{
public:
    PeaShooter(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~PeaShooter() override;
    void Update() override;
    void OnClick() override;
    int shootingtime = 30;

private:
};

#endif // !PEASHOOTER_HPP__