
#include "SunFlower.hpp"

SunFlower::SunFlower(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    SunFlower::producing_time = randInt(30, 600);
    type = 1;
    hp = 300;
}

SunFlower::~SunFlower()
{
}

void SunFlower::Update()
{

    if (hp <= 0)
    {
        hp = 0;
    }
    else
    {
        --producing_time;
        make_sun = 0;
        if (producing_time <= 0)
        {
            producing_time = 600;
            make_sun = 1;
        }
    }
}

void SunFlower::OnClick()
{
    if (energy == 0)
    {
        energy = 1;
    }
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
