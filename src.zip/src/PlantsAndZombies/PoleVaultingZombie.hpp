#ifndef POLEVAULTINGZOMBIE_HPP__
#define POLEVAULTINGZOMBIE_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class PoleVaultingZombie : public GameObject, public std::enable_shared_from_this<PoleVaultingZombie>
{
public:
    PoleVaultingZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~PoleVaultingZombie() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !POLEVAULTINGZOMBIE_HPP__