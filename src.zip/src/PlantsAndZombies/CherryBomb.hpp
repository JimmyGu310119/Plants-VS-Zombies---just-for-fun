#ifndef CHERRYBOMBS_HPP__
#define CHERRYBOMBS_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class CherryBomb : public GameObject, public std::enable_shared_from_this<CherryBomb>
{
public:
    CherryBomb(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~CherryBomb() override;
    void Update() override;
    void OnClick() override;
    int anitime = 15;

private:
};

#endif // !CHERRYBOMBS_HPP__
