#ifndef GAMEOBJECT_HPP__
#define GAMEOBJECT_HPP__

#include <memory>
#include "ObjectBase.hpp"

// Declares the class name GameWorld so that its pointers can be used.
class GameWorld;
using pGameWorld = std::shared_ptr<GameWorld>;

class GameObject : public ObjectBase, public std::enable_shared_from_this<GameObject>
{
public:
  using std::enable_shared_from_this<GameObject>::shared_from_this; // Use shared_from_this() instead of "this".
  GameObject(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
      : ObjectBase(imageID, x, y, layer, width, height, animID){};
  int hp = 10000;
  int sun_num = 0;
  int is_ob = 0;
  int anyzombie = 0;
  int make_sun = 0;
  int caltime = 0;
  int shootingswitch = 0;

  int isclick = 0;
  int lqfnl = 0;
  int suncost = 10000;

  int type = 2;
  int ispea = 0;
  int beidakai = 0;
  int kezhongzhi = 1;
  int cool;
  int kenyao = 0;
  int isboom = 0;
  int makeboom = 0;
  int ispeashooter = 0;
  int producepea = 0;
  int secondshoot = 0;
  int switchon = 0;
  int switchoff = 0;
  int shovelclick = 0;
  int shovelready = 0;
  int shovelok = 0;
  int isdead = 0;
  int energy = 0;
  int jianguo = 0;
  int isjianguoqiang = 0;

private:
};

#endif // !GAMEOBJECT_HPP__
