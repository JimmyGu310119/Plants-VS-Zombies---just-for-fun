#include "GameWorld.hpp"
#include "GameObject.hpp"
#include <iostream>
GameWorld::GameWorld() {}

GameWorld::~GameWorld() {}

void GameWorld::Init()
{
  // YOUR CODE HERE
  SetWave(0);
  SetSun(50);
  std::shared_ptr<Background> background = std::make_shared<Background>(IMGID_BACKGROUND, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2, LAYER_BACKGROUND, WINDOW_WIDTH, WINDOW_HEIGHT, ANIMID_NO_ANIMATION);
  AllThings.push_back(background);
  for (int i = 0; i != 5; ++i)
  {
    for (int j = 0; j != 9; ++j)
    {
      std::shared_ptr<lawn> new_lawn = std::make_shared<lawn>(IMGID_NONE, FIRST_COL_CENTER + LAWN_GRID_WIDTH * j, FIRST_ROW_CENTER + LAWN_GRID_HEIGHT * i, LAYER_UI, 60, 80, ANIMID_NO_ANIMATION);
      AllThings.push_back(new_lawn);
    }
  }
  std::shared_ptr<CherryBombSeed> cherrybombseed = std::make_shared<CherryBombSeed>(IMGID_SEED_CHERRY_BOMB, 310, WINDOW_HEIGHT - 44, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION);
  AllThings.push_back(cherrybombseed);
  std::shared_ptr<PeaShooterSeed> peashooterseed = std::make_shared<PeaShooterSeed>(IMGID_SEED_PEASHOOTER, 190, WINDOW_HEIGHT - 44, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION);
  AllThings.push_back(peashooterseed);
  std::shared_ptr<RepeaterSeed> repeaterseed = std::make_shared<RepeaterSeed>(IMGID_SEED_REPEATER, 370, WINDOW_HEIGHT - 44, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION);
  AllThings.push_back(repeaterseed);
  std::shared_ptr<SunFlowerSeed> sunflowerseed = std::make_shared<SunFlowerSeed>(IMGID_SEED_SUNFLOWER, 130, WINDOW_HEIGHT - 44, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION);
  AllThings.push_back(sunflowerseed);
  std::shared_ptr<WallnutSeed> wallnutseed = std::make_shared<WallnutSeed>(IMGID_SEED_WALLNUT, 250, WINDOW_HEIGHT - 44, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION);
  AllThings.push_back(wallnutseed);
  std::shared_ptr<Shovel> shovel = std::make_shared<Shovel>(IMGID_SHOVEL, 600, WINDOW_HEIGHT - 40, LAYER_UI, 50, 50, ANIMID_NO_ANIMATION);
  AllThings.push_back(shovel);
  // std::shared_ptr<BucketHeadZombie> bucketheadzombie = std::make_shared<BucketHeadZombie>(IMGID_BUCKET_HEAD_ZOMBIE, randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + randInt(0, 4) * LAWN_GRID_HEIGHT, LAYER_ZOMBIES, 20, 80, ANIMID_WALK_ANIM);
  // AllThings.push_back(bucketheadzombie);
}

LevelStatus GameWorld::Update()
{
  producezombie = 0;
  int now_sun = GetSun();

  ++time;
  ++suntime;
  ++wavetime;
  if (wavetime >= 1200)
  {
    SetWave(1);
    producezombie = 1;
    wavetime = 0;
  }
  if (GetWave() >= 1)
  {
    int interval = std::max(150, 600 - 20 * (GetWave() - 1));
    if (wavetime >= interval)
    {
      SetWave(GetWave() + 1);
      producezombie = 1;
      wavetime = 0;
    }
  }
  // judge wave
  zombienum = int((15 + GetWave()) / 10);
  p1 = 20;
  p2 = 2 * std::max(GetWave() - 8, 0);
  p3 = 3 * std::max(GetWave() - 15, 0);
  if (producezombie == 1)
  {
    for (int i = 0; i < zombienum; ++i)
    {
      regularzombienum = randInt(0, p1 + p2 + p3);
      if (0 <= regularzombienum && regularzombienum < p1)
      {
        std::shared_ptr<RegularZombie> regularzombie = std::make_shared<RegularZombie>(IMGID_REGULAR_ZOMBIE, randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + randInt(0, 4) * LAWN_GRID_HEIGHT, LAYER_ZOMBIES, 20, 80, ANIMID_WALK_ANIM);
        AllThings.push_back(regularzombie);
      }
      else if (p1 <= regularzombienum && regularzombienum < p2)
      {
        std::shared_ptr<PoleVaultingZombie> polevaultingzombie = std::make_shared<PoleVaultingZombie>(IMGID_POLE_VAULTING_ZOMBIE, randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + randInt(0, 4) * LAWN_GRID_HEIGHT, LAYER_ZOMBIES, 20, 80, ANIMID_RUN_ANIM);
        AllThings.push_back(polevaultingzombie);
      }
      else if (p2 <= regularzombienum && regularzombienum < p3)
      {
        std::shared_ptr<BucketHeadZombie> bucketheadzombie = std::make_shared<BucketHeadZombie>(IMGID_BUCKET_HEAD_ZOMBIE, randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + randInt(0, 4) * LAWN_GRID_HEIGHT, LAYER_ZOMBIES, 20, 80, ANIMID_WALK_ANIM);
        AllThings.push_back(bucketheadzombie);
      }
    }
  }
  producezombie = 0;
  // produce zombies
  if (suntime == 180)
  {
    std::shared_ptr<FallingSun> fallingsun = std::make_shared<FallingSun>(IMGID_SUN, 600, WINDOW_HEIGHT - 1, LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM);
    AllThings.push_back(fallingsun);
  }
  else if (suntime == 480)
  {
    std::shared_ptr<FallingSun> fallingsun = std::make_shared<FallingSun>(IMGID_SUN, 600, WINDOW_HEIGHT - 1, LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM);
    AllThings.push_back(fallingsun);
    suntime = suntime - 300;
  }
  // produce zombies
  for (auto it = AllThings.begin(); it != AllThings.end(); ++it)
  {
    (*it)->Update();
    (*it)->kenyao = 0;
    if ((*it)->GetX() < 0)
    {
      if ((*it)->type == 3)
      {
        return LevelStatus::LOSING;
      }
    }
    // judge lost
    int flag = 0;
    if ((*it)->type == 3)
    {
      for (auto pp = AllThings.begin(); pp != AllThings.end(); ++pp)
      {
        if ((*pp)->type == 1)
        {
          if (((*it)->GetWidth() + (*pp)->GetWidth()) / 2 > (std::abs((*it)->GetX() - (*pp)->GetX())) && ((*it)->GetHeight() + (*pp)->GetHeight()) / 2 > (std::abs((*it)->GetY() - (*pp)->GetY())))
          {
            flag = 1;
            (*it)->kenyao = 1;
            if ((*it)->switchon == 0)
            {
              (*it)->PlayAnimation(ANIMID_EAT_ANIM);
              (*it)->switchon = 1;
              (*it)->switchoff = 0;
            }
            (*pp)->hp -= 3;
          }
        }
      }
    }
    if (flag == 0 && (*it)->type == 3)
    {
      (*it)->kenyao = 2;
    }
    // judge eating
    if ((*it)->ispea == 1)
    {
      for (auto pp = AllThings.begin(); pp != AllThings.end(); ++pp)
      {
        if ((*pp)->type == 3)
        {
          if (((*it)->GetWidth() + (*pp)->GetWidth()) / 2 > (std::abs((*it)->GetX() - (*pp)->GetX())) && ((*it)->GetHeight() + (*pp)->GetHeight()) / 2 > (std::abs((*it)->GetY() - (*pp)->GetY())))
          {
            (*it)->hp = 0;
            (*pp)->hp -= 20;
          }
        }
      }
    }
    // judge hurting
    if ((*it)->makeboom == 1)
    {
      std::shared_ptr<Boom> boom = std::make_shared<Boom>(IMGID_EXPLOSION, (*it)->GetX(), (*it)->GetY(), LAYER_PROJECTILES, 3 * LAWN_GRID_WIDTH, 3 * LAWN_GRID_HEIGHT, ANIMID_NO_ANIMATION);
      AllThings.push_back(boom);
    }
    if ((*it)->isboom == 1)
    {
      for (auto pp = AllThings.begin(); pp != AllThings.end(); ++pp)
      {
        if ((*pp)->type == 3)
        {
          if (((*it)->GetWidth() + (*pp)->GetWidth()) / 2 > (std::abs((*it)->GetX() - (*pp)->GetX())) && ((*it)->GetHeight() + (*pp)->GetHeight()) / 2 > (std::abs((*it)->GetY() - (*pp)->GetY())))
          {
            (*pp)->hp -= 5000;
          }
        }
      }
    }
    // judge boom
    if ((*it)->ispeashooter == 1)
    {
      for (auto pp = AllThings.begin(); pp != AllThings.end(); ++pp)
      {
        if ((*pp)->type == 3)
        {
          if ((*it)->GetY() == (*pp)->GetY())
          {
            (*it)->shootingswitch = 1;
            break;
          }
        }
        (*it)->shootingswitch = 0;
      }
    }
    if ((*it)->producepea == 1)
    {
      if ((*it)->energy == 0)
      {
        std::shared_ptr<Pea> pea = std::make_shared<Pea>(IMGID_PEA, (*it)->GetX() + 30, (*it)->GetY() + 20, LAYER_PROJECTILES, 28, 28, ANIMID_NO_ANIMATION);
        AllThings.push_back(pea);
        (*it)->producepea = 0;
      }
      if ((*it)->energy == 1)
      {
        if (GetSun() >= 200)
        {
          for (int i = 0; i != 30; ++i)
          {
            std::shared_ptr<Pea> pea = std::make_shared<Pea>(IMGID_PEA, (*it)->GetX() + randInt(0, 50), (*it)->GetY() + randInt(0, 30), LAYER_PROJECTILES, 28, 28, ANIMID_NO_ANIMATION); //(*it)->GetX() + 30, (*it)->GetY() + 20
            AllThings.push_back(pea);
          }

          (*it)->producepea = 0;
          SetSun(GetSun() - 200);
        }
        (*it)->energy = 0;
      }
    }
    // judge shooting
    if ((*it)->sun_num == 1)
    {
      SetSun(now_sun + 25);
    }
    // Collecting falling sun
    if ((*it)->make_sun == 1)
    {
      if ((*it)->energy == 0 || ((*it)->energy == 1 && GetSun() < 200))
      {
        std::shared_ptr<ProducedSun> producedsun = std::make_shared<ProducedSun>(IMGID_SUN, (*it)->GetX(), (*it)->GetY(), LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM);
        AllThings.push_back(producedsun);
        (*it)->make_sun = 0;
        (*it)->energy = 0;
      }
      else
      {
        if ((*it)->jianguo == 0)
        {
          SetSun(GetSun() - 200);
          (*it)->jianguo = 1;
        }
        for (int y = 0; y != 2; ++y)
        {
          std::shared_ptr<ProducedSun> producedsun = std::make_shared<ProducedSun>(IMGID_SUN, (*it)->GetX(), (*it)->GetY(), LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(producedsun);
        }
        (*it)->make_sun = 0;
      }
    }
    // Advanced Sunflower
    int flag2 = 0;
    if ((*it)->type == 3)
    {
      for (auto pp = AllThings.begin(); pp != AllThings.end(); ++pp)
      {
        if ((*pp)->type == 1)
        {
          if (((*it)->GetWidth() + (*pp)->GetWidth()) / 2 > (std::abs((*it)->GetX() - (*pp)->GetX())) && ((*it)->GetHeight() + (*pp)->GetHeight()) / 2 > (std::abs((*it)->GetY() - (*pp)->GetY())))
          {
            flag2 = 1;
            (*it)->kenyao = 1;
            if ((*it)->switchon == 0)
            {
              (*it)->PlayAnimation(ANIMID_EAT_ANIM);
              (*it)->switchon = 1;
              (*it)->switchoff = 0;
            }
            (*pp)->hp -= 3;
          }
        }
      }
    }
    if (flag2 == 0 && (*it)->type == 3)
    {
      (*it)->kenyao = 2;
    }
    // again judge eating
    if ((*it)->isjianguoqiang == 1 && (*it)->energy == 1)
    {
      if (GetSun() >= 200)
      {
        (*it)->hp += 2000;
        SetSun(GetSun() - 200);
        (*it)->energy = 0;
      }
    }
    // Advanced Wallnut
    if ((*it)->isclick == 1)
    {
      if ((*it)->suncost <= GetSun())
      {
        for (auto bbb = AllThings.begin(); bbb != AllThings.end(); ++bbb)
        {
          (*bbb)->beidakai = 1;
        }
        std::shared_ptr<CooldownMask> cooldownmask = std::make_shared<CooldownMask>(IMGID_COOLDOWN_MASK, (*it)->GetX(), (*it)->GetY(), LAYER_COOLDOWN_MASK, 50, 70, ANIMID_NO_ANIMATION);
        (*cooldownmask).cooltime = (*it)->cool;
        AllThings.push_back(cooldownmask);
        if ((*it)->lqfnl == 1)
        {
          planting_num = 1;
        }
        else if ((*it)->lqfnl == 2)
        {
          planting_num = 2;
        }
        else if ((*it)->lqfnl == 3)
        {
          planting_num = 3;
        }
        else if ((*it)->lqfnl == 4)
        {
          planting_num = 4;
        }
        else if ((*it)->lqfnl == 5)
        {
          planting_num = 5;
        }
        (*it)->isclick = 0;
      }
      (*it)->isclick = 0;
    }
    int loop = 0;
    // clicking seed
    if ((*it)->shovelclick == 1)
    {
      for (auto bbb = AllThings.begin(); bbb != AllThings.end(); ++bbb)
      {

        (*bbb)->beidakai = 1;
        if ((*bbb)->type == 1)
        {
          (*bbb)->shovelready = 1;
        }
      }
    }
    if ((*it)->shovelok == 1)
    {
      (*it)->shovelok = 0;
      AllThings.erase(it);
      for (auto bbb = AllThings.begin(); bbb != AllThings.end(); ++bbb)
      {
        (*bbb)->beidakai = 0;
        if ((*bbb)->type == 1)
        {
          (*bbb)->shovelready = 0;
        }
      }
    }
    // remove plant
    if ((*it)->kezhongzhi == 0)
    {

      if (planting_num == 1 || planting_num == 2 || planting_num == 3 || planting_num == 4 || planting_num == 5)
      {

        if (planting_num == 1)
        {
          std::shared_ptr<SunFlower> sunflower = std::make_shared<SunFlower>(IMGID_SUNFLOWER, (*it)->GetX(), (*it)->GetY(), LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(sunflower);
          SetSun(GetSun() - 50);
          planting_num = 0;
        }
        else if (planting_num == 2)
        {
          std::shared_ptr<PeaShooter> peashooter = std::make_shared<PeaShooter>(IMGID_PEASHOOTER, (*it)->GetX(), (*it)->GetY(), LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(peashooter);
          SetSun(GetSun() - 100);
          planting_num = 0;
        }
        else if (planting_num == 3)
        {
          std::shared_ptr<Wallnut> wallnut = std::make_shared<Wallnut>(IMGID_WALLNUT, (*it)->GetX(), (*it)->GetY(), LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(wallnut);
          SetSun(GetSun() - 50);
          planting_num = 0;
        }
        else if (planting_num == 4)
        {
          std::shared_ptr<CherryBomb> cherrybomb = std::make_shared<CherryBomb>(IMGID_CHERRY_BOMB, (*it)->GetX(), (*it)->GetY(), LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(cherrybomb);
          SetSun(GetSun() - 150); // 150
          planting_num = 0;
        }
        else if (planting_num == 5)
        {
          std::shared_ptr<Repeater> repeater = std::make_shared<Repeater>(IMGID_REPEATER, (*it)->GetX(), (*it)->GetY(), LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM);
          AllThings.push_back(repeater);
          SetSun(GetSun() - 200);
          planting_num = 0;
        }
      }
      (*it)->kezhongzhi = 1;
      loop = 1;
    }
    else
    {
      (*it)->kezhongzhi = 1;
    }
    if (loop == 1)
    {
      for (auto sbs = AllThings.begin(); sbs != AllThings.end(); ++sbs)
      {
        (*sbs)->isclick = 0;
        (*sbs)->beidakai = 0;
      }
    }
    // clicking lawn
    // if ((*it)->shoot == 1)
    //{
    //  std::shared_ptr<Pea> pea = std::make_shared<Pea>(IMGID_SUN, 600, WINDOW_HEIGHT - 1, LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM);
    // AllThings.push_back(pea);
    //  }
    // Pea shooting
    if ((*it)->hp == 0)
    {
      AllThings.erase(it);
    }
    // remove dead things

    // if ((*it)->shoot = 1)
    // {
    //   std::shared_ptr<Pea> pea = std::make_shared<Pea>(IMGID_PEA, (*it)->GetX(), (*it)->GetY(), LAYER_PROJECTILES, 28, 28, ANIMID_NO_ANIMATION);
    //   AllThings.push_back(pea);
    //   (*it)->shoot = 0;
    // }
  }

  return LevelStatus::ONGOING;
}
void GameWorld::CleanUp()
{
  // YOUR CODE HERE
  AllThings.clear();
}