
#include "Wallnut.hpp"

Wallnut::Wallnut(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    isjianguoqiang = 1;
    hp = 4000;
    type = 1;
}

Wallnut::~Wallnut()
{
}

void Wallnut::Update()
{
    if (hp < int(4000 / 3) && hp >= 0)
    {
        ChangeImage(IMGID_WALLNUT_CRACKED);
    }
    if (hp <= 0)
    {
        hp = 0;
    }
}

void Wallnut::OnClick()
{
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
