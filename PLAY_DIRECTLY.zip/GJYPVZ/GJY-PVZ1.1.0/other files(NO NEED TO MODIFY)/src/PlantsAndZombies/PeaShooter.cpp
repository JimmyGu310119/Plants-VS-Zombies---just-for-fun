#include "GameWorld.hpp"
#include "PeaShooter.hpp"

PeaShooter::PeaShooter(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    hp = 300;
    type = 1;
    ispeashooter = 1;
}

PeaShooter::~PeaShooter()
{
}

void PeaShooter::Update()
{
    if (energy == 0)
    {
        --shootingtime;
        if (shootingswitch == 1 && shootingtime <= 0)
        {
            producepea = 1;
            shootingtime = 30;
        }
    }
    else
    {
        producepea = 1;
        shootingtime = 30;
    }
    if (hp <= 0)
    {
        hp = 0;
    }
}

void PeaShooter::OnClick()
{
    energy = 1;
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
