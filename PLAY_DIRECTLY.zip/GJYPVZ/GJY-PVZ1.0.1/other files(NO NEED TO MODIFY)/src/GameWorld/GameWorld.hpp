#ifndef GAMEWORLD_HPP__
#define GAMEWORLD_HPP__

#include <list>
#include <memory>

#include "WorldBase.hpp"
#include "utils.hpp"
#include "BackGround.hpp"
#include "lawn.hpp"
#include "CherryBombSeed.hpp"
#include "PeaShooterSeed.hpp"
#include "RepeaterSeed.hpp"
#include "SunFlowerSeed.hpp"
#include "WallnutSeed.hpp"
#include "Shovel.hpp"
#include "FallingSun.hpp"
#include "ProducedSun.hpp"
#include "SunFlower.hpp"
#include "Pea.hpp"
#include "RegularZombie.hpp"
#include "PeaShooter.hpp"
#include "Repeater.hpp"
#include "Wallnut.hpp"
#include "BucketHeadZombie.hpp"
#include "CherryBomb.hpp"
#include "CooldownMask.hpp"
#include "SunFlower.hpp"
#include "PeaShooter.hpp"
#include "Wallnut.hpp"
#include "CherryBomb.hpp"
#include "Repeater.hpp"
#include "PoleVaultingZombie.hpp"
#include "Boom.hpp"

class GameWorld : public WorldBase, public std::enable_shared_from_this<GameWorld>
{
public:
  // Use shared_from_this() instead of "this".
  GameWorld();
  virtual ~GameWorld();

  void Init() override;

  LevelStatus Update() override;

  void CleanUp() override;

  std::list<std::shared_ptr<GameObject>> AllThings;
  int time = 0;
  int suntime = 0;
  int wavetime = 0;
  int zombienum = 0;
  int producezombie = 0;
  int p1, p2, p3 = 0;
  int regularzombienum = 0;
  int bucketheadzombienum = 0;
  int polevaultingzombienum = 0;
  int planting_num = 0;

private:
};

#endif // !GAMEWORLD_HPP__
