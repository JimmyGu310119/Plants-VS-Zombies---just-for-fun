
#include "PoleVaultingZombie.hpp"

PoleVaultingZombie::PoleVaultingZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    type = 3;
    hp = 380;
    kenyao = 2;
}

PoleVaultingZombie::~PoleVaultingZombie()
{
}

void PoleVaultingZombie::Update()
{
    if (hp <= 0)
    {
        hp = 0;
    }
    else if (kenyao == 2 && hp > 0)
    {
        MoveTo(GetX() - 1, GetY());
        PlayAnimation(ANIMID_WALK_ANIM);
    }
    if (kenyao == 1)
    {
        PlayAnimation(ANIMID_EAT_ANIM);
    }
}

void PoleVaultingZombie::OnClick()
{
}
