
#include "CherryBomb.hpp"

CherryBomb::CherryBomb(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    hp = 4000;
    type = 1;
}

CherryBomb::~CherryBomb()
{
}

void CherryBomb::Update()
{
    --anitime;
    if (anitime <= 0)
    {
        hp = 0;
        makeboom = 1;
    }
}

void CherryBomb::OnClick()
{
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
