#ifndef REGULARZOMBIE_HPP__
#define REGULARZOMBIE_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class RegularZombie : public GameObject, public std::enable_shared_from_this<RegularZombie>
{
public:
    RegularZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~RegularZombie() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !REGULARZOMBIE_HPP__