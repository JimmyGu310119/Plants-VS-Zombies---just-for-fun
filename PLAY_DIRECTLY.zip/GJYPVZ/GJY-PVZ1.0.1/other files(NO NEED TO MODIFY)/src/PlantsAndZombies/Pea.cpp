
#include "Pea.hpp"

Pea::Pea(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    ispea = 1;
}

Pea::~Pea()
{
}

void Pea::Update()
{
    if (hp <= 0)
    {
        hp = 0;
    }
    else
    {
        MoveTo(GetX() + 8, GetY());
    }
    if (GetX() >= WINDOW_WIDTH)
    {
        hp = 0;
    }
}

void Pea::OnClick()
{
}
