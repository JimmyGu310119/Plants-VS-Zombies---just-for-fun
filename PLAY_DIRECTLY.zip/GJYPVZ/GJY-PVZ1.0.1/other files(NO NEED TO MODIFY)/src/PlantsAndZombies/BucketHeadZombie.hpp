#ifndef BUCKETHEADZOMBIE_HPP__
#define BUCKETHEADZOMBIE_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class BucketHeadZombie : public GameObject, public std::enable_shared_from_this<BucketHeadZombie>
{
public:
    BucketHeadZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~BucketHeadZombie() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !BUCKETHEADZOMBIE_HPP__