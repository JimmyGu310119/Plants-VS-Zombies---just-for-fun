#ifndef REPEATER_HPP__
#define REPEATER_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Repeater : public GameObject, public std::enable_shared_from_this<Repeater>
{
public:
    Repeater(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Repeater() override;
    void Update() override;
    void OnClick() override;
    int shootingtime = 30;

private:
};

#endif // !REPEATER_HPP__