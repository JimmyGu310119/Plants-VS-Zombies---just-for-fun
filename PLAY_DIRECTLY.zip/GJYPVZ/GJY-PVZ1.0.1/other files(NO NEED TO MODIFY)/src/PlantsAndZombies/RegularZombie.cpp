
#include "RegularZombie.hpp"

RegularZombie::RegularZombie(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    type = 3;
    hp = 200;
    kenyao = 2;
}

RegularZombie::~RegularZombie()
{
}

void RegularZombie::Update()
{
    if (hp <= 0)
    {
        hp = 0;
    }
    else if (kenyao == 2 && hp > 0)
    {
        MoveTo(GetX() - 1, GetY());
        if (switchoff == 0)
        {
            PlayAnimation(ANIMID_WALK_ANIM);
            switchoff = 1;
        }
    }
}

void RegularZombie::OnClick()
{
}
