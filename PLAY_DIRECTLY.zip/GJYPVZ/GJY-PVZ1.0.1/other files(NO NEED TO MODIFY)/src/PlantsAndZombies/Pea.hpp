#ifndef PEA_HPP__
#define PEA_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Pea : public GameObject, public std::enable_shared_from_this<Pea>
{
public:
    Pea(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Pea() override;
    void Update() override;
    void OnClick() override;
    int type = 1;

private:
};

#endif // !PEA_HPP__