
#include "Repeater.hpp"

Repeater::Repeater(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    hp = 300;
    type = 1;
    ispeashooter = 1;
}

Repeater::~Repeater()
{
}

void Repeater::Update()
{
    --shootingtime;
    if (shootingswitch == 1 && shootingtime <= 0)
    {
        producepea = 1;
        shootingtime = 30;
        secondshoot = 1;
    }
    if (shootingswitch == 1 && shootingtime <= 25 && secondshoot == 1)
    {
        producepea = 1;
        secondshoot = 0;
    }
}

void Repeater::OnClick()
{
    if (shovelready == 1)
    {
        shovelok = 1;
    }
}
