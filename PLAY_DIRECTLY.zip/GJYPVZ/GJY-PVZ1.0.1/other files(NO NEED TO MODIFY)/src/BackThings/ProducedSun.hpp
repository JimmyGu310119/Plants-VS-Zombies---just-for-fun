#ifndef PRODUCEDSUN_HPP__
#define PRODUCEDSUN_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class ProducedSun : public GameObject, public std::enable_shared_from_this<ProducedSun>
{
public:
    ProducedSun(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~ProducedSun() override;
    void Update()
    {
        if (falling_time < 12)
        {
            ++falling_time;

            MoveTo(GetX() - 1, GetY() + (5 - falling_time));
        }
        else
        {
            if (existing_time <= 300)
            {
                --existing_time;
            }
            else
            {
                hp = 0;
            }
        }
    }

    void OnClick()
    {
        hp = 0;
        sun_num = 1;
    }
    int falling_time = 0;
    int existing_time = 300;

private:
};

#endif // !PRODUCEDSUN_HPP__
