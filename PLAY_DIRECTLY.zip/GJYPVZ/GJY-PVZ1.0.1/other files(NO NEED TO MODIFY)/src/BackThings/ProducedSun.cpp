#include "ProducedSun.hpp"
#include "utils.hpp"
ProducedSun::ProducedSun(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID) {}

ProducedSun::~ProducedSun()
{
}
