
#include "lawn.hpp"

lawn::lawn(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
}

lawn::~lawn()
{
}

void lawn::Update()
{
}

void lawn::OnClick()
{
    kezhongzhi = 0;
}
