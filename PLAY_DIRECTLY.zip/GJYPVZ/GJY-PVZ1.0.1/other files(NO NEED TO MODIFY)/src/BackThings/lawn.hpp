#ifndef LAWN_HPP__
#define LAWN_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"
class GameWorld;
class lawn : public GameObject, public std::enable_shared_from_this<lawn>
{
public:
    lawn(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~lawn() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !LAWN_HPP__
