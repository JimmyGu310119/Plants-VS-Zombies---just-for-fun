#ifndef WALLNUTSEED_HPP__
#define WALLNUTSEED_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class WallnutSeed : public GameObject, public std::enable_shared_from_this<WallnutSeed>
{
public:
    WallnutSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~WallnutSeed() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !WALLNUTSEED_HPP__
