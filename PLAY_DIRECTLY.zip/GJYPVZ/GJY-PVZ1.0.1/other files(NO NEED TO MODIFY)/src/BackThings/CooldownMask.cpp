#include "CooldownMask.hpp"

CooldownMask::CooldownMask(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
}

CooldownMask::~CooldownMask()
{
}

void CooldownMask::Update()
{
    --cooltime;
    if (cooltime <= 0)
    {
        hp = 0;
    }
}

void CooldownMask::OnClick()
{
}
