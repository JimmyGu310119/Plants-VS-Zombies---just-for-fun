#include "PeaShooterSeed.hpp"
#include "GameWorld.hpp"
PeaShooterSeed::PeaShooterSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    suncost = 100;
    lqfnl = 2;
    cool = 240;
}

PeaShooterSeed::~PeaShooterSeed()
{
}

void PeaShooterSeed::Update()
{
}

void PeaShooterSeed::OnClick()
{
    if (isclick == 0 && beidakai == 0)
    {
        isclick = 1;
        lqfnl = 2;
    }
}