#ifndef SHOVEL_HPP__
#define SHOVEL_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Shovel : public GameObject, public std::enable_shared_from_this<Shovel>
{
public:
    Shovel(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Shovel() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !SHOVEL_HPP__
