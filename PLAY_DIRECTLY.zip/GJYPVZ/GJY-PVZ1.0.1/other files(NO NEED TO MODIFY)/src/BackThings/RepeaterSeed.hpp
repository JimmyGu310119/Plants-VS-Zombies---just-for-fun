#ifndef REPEATERSEED_HPP__

#define REPEATERSEED_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class RepeaterSeed : public GameObject, public std::enable_shared_from_this<RepeaterSeed>
{
public:
    RepeaterSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~RepeaterSeed() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !REPEATERSEED_HPP__
