#ifndef SUNFLOWERSEED_HPP__
#define SUNFLOWERSEED_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class SunFlowerSeed : public GameObject, public std::enable_shared_from_this<SunFlowerSeed>
{
public:
    SunFlowerSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~SunFlowerSeed() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !SUNFLOWERSEED_HPP__
