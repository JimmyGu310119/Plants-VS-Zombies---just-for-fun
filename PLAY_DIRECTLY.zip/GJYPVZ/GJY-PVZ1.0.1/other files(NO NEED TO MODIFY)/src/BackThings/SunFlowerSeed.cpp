#include "GameWorld.hpp"
#include "SunFlowerSeed.hpp"

SunFlowerSeed::SunFlowerSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    suncost = 50;
    lqfnl = 1;
    cool = 240;
}

SunFlowerSeed::~SunFlowerSeed()
{
}

void SunFlowerSeed::Update()
{
}

void SunFlowerSeed::OnClick()
{
    if (isclick == 0 && beidakai == 0)
    {
        isclick = 1;
        lqfnl = 1;
    }
}
