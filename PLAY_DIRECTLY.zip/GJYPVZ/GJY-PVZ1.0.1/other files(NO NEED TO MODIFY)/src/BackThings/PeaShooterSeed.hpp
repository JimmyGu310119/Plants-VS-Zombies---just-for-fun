#ifndef PEASHOOTERSEED_HPP__
#define PEASHOOTERSEED_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class PeaShooterSeed : public GameObject, public std::enable_shared_from_this<PeaShooterSeed>
{
public:
    PeaShooterSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~PeaShooterSeed() override;
    void Update() override;
    void OnClick() override;

private:
};

#endif // !PEASHOOTERSEED_HPP__
