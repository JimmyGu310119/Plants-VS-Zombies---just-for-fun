
#include "CherryBombSeed.hpp"

CherryBombSeed ::CherryBombSeed(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
    suncost = 150; // 150//GameWorld.cpp line 329
    lqfnl = 4;
    cool = 1200; // 1200
}

CherryBombSeed::~CherryBombSeed()
{
}

void CherryBombSeed::Update()
{
}

void CherryBombSeed::OnClick()
{
    if (isclick == 0 && beidakai == 0)
    {
        isclick = 1;
        lqfnl = 4;
    }
}
