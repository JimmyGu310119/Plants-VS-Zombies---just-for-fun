#ifndef BOOM_HPP__
#define BOOM_HPP__

#include "GameObject.hpp"
#include "GameWorld.hpp"

class Boom : public GameObject, public std::enable_shared_from_this<Boom>
{
public:
    Boom(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID);
    ~Boom() override;
    void Update() override;
    void OnClick() override;
    int etime = 3;

private:
};

#endif // !BOOM_HPP__
