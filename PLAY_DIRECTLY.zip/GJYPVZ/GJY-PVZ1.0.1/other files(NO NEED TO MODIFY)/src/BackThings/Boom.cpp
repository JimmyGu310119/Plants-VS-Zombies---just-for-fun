#include "Boom.hpp"

Boom::Boom(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID)
    : GameObject(imageID, x, y, layer, width, height, animID)
{
}

Boom::~Boom()
{
}

void Boom::Update()
{
    --etime;
    if (etime == 3)
    {

        isboom = 1;
    }
    if (etime == 2)
    {

        isboom = 1;
    }
    if (etime == 1)
    {

        isboom = 1;
        hp = 0;
    }
}

void Boom::OnClick()
{
}
